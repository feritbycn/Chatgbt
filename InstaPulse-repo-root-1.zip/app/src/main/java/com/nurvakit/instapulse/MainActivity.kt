package com.nurvakit.instapulse

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10101A)
private val Panel = Color(0xFF1B1B29)
private val Purple = Color(0xFF8B5CF6)
private val Mint = Color(0xFF36E0B2)
private val Muted = Color(0xFF9A9AAF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InstaPulseApp() }
    }
}

@Composable
fun InstaPulseApp() {
    var tab by remember { mutableStateOf("Ana Sayfa") }
    val context = LocalContext.current
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Purple, secondary = Mint)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Color(0xFF171722), contentColor = Color.White) {
                listOf("Ana Sayfa" to Icons.Default.Home, "Analiz" to Icons.Default.Analytics, "Etkileşim" to Icons.Default.FavoriteBorder, "Premium" to Icons.Default.Star).forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint, indicatorColor = Color(0xFF303044), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { pad ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 26.dp)) {
                item { Header(onProfile = { tab = "Hesap" }) }
                when (tab) {
                    "Ana Sayfa" -> {
                        item { WelcomeCard(onConnect = { Toast.makeText(context, "Instagram bağlantısı için resmî OAuth kurulumu gerekli. Bu demo şifre istemez.", Toast.LENGTH_LONG).show() }) }
                        item { Text("Bugünün özeti", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("Takipçi", "12.8K", "+124", Mint, Modifier.weight(1f)); StatCard("Etkileşim", "8.6%", "+1.2%", Purple, Modifier.weight(1f)) } }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("Takip edilen", "842", "Analiz", Color(0xFFFFB454), Modifier.weight(1f)); StatCard("İçerik", "36", "Bu ay", Color(0xFF5CB8FF), Modifier.weight(1f)) } }
                        item { SectionTitle("Hızlı araçlar", "Günlük işlerini tek yerden yönet") }
                        item { ToolRow(Icons.Default.Group, "Karşılıklı takip kontrolü", "Takip listelerini karşılaştır", "Aç", Purple) { tab = "Analiz" } }
                        item { ToolRow(Icons.Default.TrendingUp, "Etkileşim sıralaması", "En çok etkileşim kuran hesaplar", "Gör", Mint) { tab = "Etkileşim" } }
                        item { ToolRow(Icons.Default.ChatBubbleOutline, "Mesaj otomasyonu", "Anahtar kelimeye göre yanıt taslakları", "Kur", Color(0xFFFFB454)) { Toast.makeText(context, "Mesaj kuralları ekranı sonraki entegrasyon adımında etkinleştirilecek.", Toast.LENGTH_SHORT).show() } }
                        item { AdCreditCard(onWatch = { Toast.makeText(context, "Ödüllü reklam sağlayıcısı bağlandığında krediler etkinleşir.", Toast.LENGTH_SHORT).show() }) }
                    }
                    "Analiz" -> {
                        item { SectionTitle("Hesap analizi", "Resmî API veya dışa aktarılan verilerle") }
                        item { InfoCard("Karşılıklı takip", "Seni takip etmeyen hesapları listele ve tek tek incele. Toplu otomatik takipten çıkma bu sürümde yok.", Icons.Default.Group) }
                        item { InfoCard("Takipçi değişimi", "Günlük takipçi kazanımı/kaybı, veri kaynağı bağlandıktan sonra gösterilir.", Icons.Default.TrendingUp) }
                        item { InfoCard("En iyi içerik", "Erişim, görüntüleme ve etkileşim verilerine göre en iyi performans gösteren gönderileri bul.", Icons.Default.Analytics) }
                        item { Button(onClick = { Toast.makeText(context, "Gerçek veriler için Meta uygulama kaydı ve izin onayı gerekiyor.", Toast.LENGTH_LONG).show() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Instagram hesabını bağla") } }
                    }
                    "Etkileşim" -> {
                        item { SectionTitle("Etkileşim merkezi", "Topluluğunu daha iyi tanı") }
                        item { InfoCard("En ilgili takipçiler", "Beğeni ve yorum etkileşimlerini sıralama — veri izni gerektirir.", Icons.Default.FavoriteBorder) }
                        item { InfoCard("Gönderi performansı", "Gönderi başına etkileşim oranı ve zaman içindeki değişim.", Icons.Default.TrendingUp) }
                        item { InfoCard("Akıllı hatırlatmalar", "İlgili takipçilere manuel olarak dönüş yapman için öneriler.", Icons.Default.AutoAwesome) }
                        item { Text("Otomatik toplu beğeni yerine, önerilen hesap ve gönderileri gözden geçirip kendin etkileşim kurabilirsin.", color = Muted, fontSize = 13.sp) }
                    }
                    "Premium" -> {
                        item { PremiumHero() }
                        item { Text("Premium ile aç", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        listOf("Gelişmiş analiz ve tarih aralığı", "Takipçi değişim raporları", "Sınırsız kayıtlı filtre", "Reklamsız deneyim", "Özel Premium rozeti", "Ek tema ve uygulama simgeleri").forEach { item { PremiumFeature(it) } }
                        item { Button(onClick = { Toast.makeText(context, "Ödeme sistemi için Google Play Billing entegrasyonu gerekli.", Toast.LENGTH_LONG).show() }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink), shape = RoundedCornerShape(16.dp)) { Text("Premium'u keşfet", fontWeight = FontWeight.Bold) } }
                        item { Text("Satın alma henüz demo modunda. Gerçek ödeme için Play Console ürünleri tanımlanmalıdır.", color = Muted, fontSize = 12.sp) }
                    }
                    else -> { item { InfoCard("Hesap", "Instagram bağlantısı ve uygulama tercihleri", Icons.Default.Person) } }
                }
                item { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Icon(Icons.Default.Lock, null, tint = Muted, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(6.dp)); Text("Şifreni bu demo uygulamaya girme", color = Muted, fontSize = 11.sp) } }
            }
        }
    }
}

@Composable fun Header(onProfile: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Purple, Color(0xFF5232B8))), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
        Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text("InstaPulse", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp); Text("Hesabını daha iyi tanı", color = Muted, fontSize = 12.sp) }
        Box(Modifier.size(40.dp).background(Panel, CircleShape).clickable { onProfile() }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Settings, null, tint = Color.White) }
    }
}

@Composable fun WelcomeCard(onConnect: () -> Unit) {
    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF35216B), Color(0xFF1C3444))), RoundedCornerShape(24.dp)).padding(20.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("SOSYAL MEDYA ANALİZİN", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("Hesabının nabzını\ntut. ✨", color = Color.White, fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
            Text("Takipçi trendlerini ve içerik performansını tek ekranda keşfet.", color = Color(0xFFD6D5E7), fontSize = 13.sp)
            Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink), shape = RoundedCornerShape(14.dp)) { Text("Instagram'a bağlan", fontWeight = FontWeight.Bold); Spacer(Modifier.width(6.dp)); Text("↗") }
            Text("Demo arayüz • Gerçek hesap bağlantısı henüz kurulmadı", color = Color(0xFFB7B5CA), fontSize = 10.sp)
        }
    }
}

@Composable fun StatCard(title: String, value: String, sub: String, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = Muted, fontSize = 12.sp); Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(sub, color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable fun SectionTitle(title: String, subtitle: String) { Column { Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp) } }

@Composable fun ToolRow(icon: ImageVector, title: String, desc: String, action: String, accent: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onClick() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(accent.copy(alpha = .15f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Spacer(Modifier.height(3.dp)); Text(desc, color = Muted, fontSize = 11.sp) }; Text(action, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable fun InfoCard(title: String, body: String, icon: ImageVector) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = Mint, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Column { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(body, color = Muted, fontSize = 13.sp, lineHeight = 19.sp) }
    }
}

@Composable fun AdCreditCard(onWatch: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF222237), RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(Color(0xFF39305B), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFFFD166)) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Kredi kazan", color = Color.White, fontWeight = FontWeight.Bold); Text("Ödüllü reklam izleyerek +3 kredi", color = Muted, fontSize = 11.sp) }
        Text("KAZAN", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onWatch() }.padding(5.dp))
    }
}

@Composable fun PremiumHero() {
    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF5C3CC4), Color(0xFF282345))), RoundedCornerShape(24.dp)).padding(20.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Star, null, tint = Color(0xFFFFD166)); Spacer(Modifier.width(7.dp)); Text("INSTAPULSE PRO", color = Color(0xFFFFD166), fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) }; Text("Daha derin analiz.\nDaha akıllı kararlar.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp); Text("Özel rozetin ve gelişmiş araçlarınla deneyimini yükselt.", color = Color(0xFFE1DDF7), fontSize = 13.sp) }
    }
}

@Composable fun PremiumFeature(text: String) { Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Star, null, tint = Color(0xFFFFD166), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text(text, color = Color.White, fontSize = 13.sp); Spacer(Modifier.weight(1f)); Text("PRO", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold) } }
