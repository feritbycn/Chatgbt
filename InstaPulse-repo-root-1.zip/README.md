# InstaPulse — Android starter project

Modern, dark-themed Kotlin + Jetpack Compose starter UI for an Instagram account insights companion app.

## What's included
- Dashboard with demo metrics and quick tools
- Analysis and engagement screens
- Premium screen with feature list and badge concept
- Ad-reward/credit UI placeholder
- Original vector app icon
- GitHub Actions workflow to build a debug APK

## Important status
This is a **UI prototype**, not a finished Instagram-connected product. All displayed statistics are illustrative demo values. Instagram OAuth, Meta app review/permissions, backend, billing, and ad network are not configured. Buttons explicitly notify the user when an integration is not available.

## Build an APK on GitHub
1. Create a new GitHub repository and upload the contents of this folder.
2. Open **Actions** and run **Build Android APK** (or push to `main`).
3. When the workflow finishes, download the `InstaPulse-debug-apk` artifact.

The workflow uses Gradle to build `app/build/outputs/apk/debug/app-debug.apk`.

## Build locally
Install JDK 17 and Android SDK, then run:

```bash
gradle assembleDebug
```

## Instagram integration roadmap
1. Create a Meta developer app and configure the supported Instagram Login / Instagram Graph API product for the account type you intend to support.
2. Implement OAuth authorization-code flow with redirect URI validation and server-side token exchange. Never collect or store Instagram passwords in this app.
3. Request only approved permissions and show real metrics only when the API makes them available. Personal accounts and professional accounts have different capabilities; follower lists and historical follower changes are not universally available through the API.
4. For messaging automation, use only official messaging APIs, required permissions, and policy-compliant user-initiated/business messaging flows. The current UI does not send messages or perform automatic likes/follows/unfollows.
5. Integrate Google Play Billing for Premium and a compliant ad SDK for rewarded credits. Grant credits only after the ad SDK confirms reward completion; validate purchases server-side before granting paid entitlements.
6. Add privacy policy, data deletion flow, consent disclosures, rate limiting, secure token storage, and Meta review before public release.

## Safe product boundaries
- No password collection or login scraping.
- No automated mass likes, follows, or unfollows.
- Unfollow suggestions should be reviewable and user-confirmed, subject to official API capabilities.
- Demo data is not live account data.
